package sample;

public enum LevelOfPriority {
    LOW,
    MEDIUM,
    HIGH;
}
