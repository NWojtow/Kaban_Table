package sample;


import javafx.scene.control.*;
import javafx.scene.layout.GridPane;



public class TaskCell extends ListCell<Task>  {

    //Zoverridowana komorka dla ListView zeby mozna bylo dodac wlasny obiekt

    private Button actionBtn;
    private Label name;
    private GridPane pane;


//Funkcja ktora odpowiada za wyglad komorki
    @Override
    protected void updateItem(Task item, boolean empty) {

        //Tooltip to takei fajne ze jak najedziesz myszka to ci sie pokazuje dymek z tym co jest w adnotacjach napisane
        final Tooltip tooltip = new Tooltip();
        super.updateItem(item, empty);

        setEditable(false);

        if (item != null) {

            //Ustawia co ma byc wyswietlane, korzysta z tej funkcji to string z klasy task
            setText(item.toString());
            //ustawia tego tooltipa co ma wyswietlac
            tooltip.setText(item.getAddnotation());
            //Nadje komorce tooltipa
            setTooltip(tooltip);
            setGraphic(pane);

            //Robi ze jak jest medium level to jest pomaranczowe a jak high to czerwone
            if(item.getLevel()==LevelOfPriority.MEDIUM){
                setStyle("-fx-background-color: rgba(255,135,24,0.72)");
            }
            else if(item.getLevel()==LevelOfPriority.HIGH){
                setStyle("-fx-background-color: rgba(190,12,4,0.74)");
            }

        } else {
            //Jak komorka jest pusta to nic nie wyswietla bo tak to zostawaly z poprzedniej komorki kolory itp
            setStyle(null);
            setText("");
            setGraphic(null);
        }

    }

}



