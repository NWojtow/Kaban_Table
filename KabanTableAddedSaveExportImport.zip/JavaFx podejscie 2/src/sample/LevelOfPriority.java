package sample;


//Enum z poziomem waznosci
public enum LevelOfPriority {
    LOW,
    MEDIUM,
    HIGH;
}
